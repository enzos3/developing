(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2090:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2315);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2333);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2885);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(683);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3269);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5746);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8208);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6__);

    const tree = {
      children: [
        '',
        {
      children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 965)), "D:\\Programacion\\NextCVProyect\\app\\page.js"]}]
    },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1977)), "D:\\Programacion\\NextCVProyect\\app\\layout.js"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2725)), "D:\\Programacion\\NextCVProyect\\app\\head.js"],
        }
      ]
    }.children;
    const pages = ["D:\\Programacion\\NextCVProyect\\app\\page.js"]

    
    
    

    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 7233:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1505));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3261));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7774));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7959));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3002));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8857));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1902));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8922));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2046));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7903));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 458));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5494));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8699))

/***/ }),

/***/ 4224:
/***/ (() => {



/***/ }),

/***/ 8469:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9446, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3258, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6862, 23))

/***/ }),

/***/ 3259:
/***/ (() => {



/***/ }),

/***/ 2725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8499);

const Head = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: "Enzo Fiol"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "viewport",
                content: "width=device-width, initial-scale=1"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "icon",
                href: "#"
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Head);


/***/ }),

/***/ 1977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8499);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6495);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);


const RootLayout = ({ children  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("html", {
        lang: "en",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("head", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "preconnect",
                        href: "https://stijndv.com"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "stylesheet",
                        href: "https://stijndv.com/fonts/Eudoxus-Sans.css"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
                children: children
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RootLayout);


/***/ }),

/***/ 965:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(8499);
// EXTERNAL MODULE: ./components/Navbar.jsx
var Navbar = __webpack_require__(3611);
var Navbar_default = /*#__PURE__*/__webpack_require__.n(Navbar);
// EXTERNAL MODULE: ./components/CustomTexts.jsx
var CustomTexts = __webpack_require__(5569);
// EXTERNAL MODULE: ./components/ExploreCard.jsx
var ExploreCard = __webpack_require__(2547);
;// CONCATENATED MODULE: ./styles/index.js
const styles_styles = {
    innerWidth: "2xl:max-w-[1280px] w-full",
    interWidth: "lg:w-[80%] w-[100%]",
    paddings: "sm:p-16 xs:p-8 px-6 py-12",
    yPaddings: "sm:py-16 xs:py-8 py-12",
    xPaddings: "sm:px-16 px-6",
    topPaddings: "sm:pt-16 xs:pt-8 pt-12",
    bottomPaddings: "sm:pb-16 xs:pb-8 pb-12",
    flexCenter: "flex justify-center items-center",
    flexStart: "flex justify-start items-start",
    flexEnd: "flex justify-end",
    navPadding: "pt-[98px]",
    // hero section
    heroHeading: "font-bold lg:text-[144px] md:text-[100px] sm:text-[60px] text-[44px] lg:leading-[158.4px] md:leading-[114.4px] sm:leading-[74.4px] leading-[64.4px] uppercase text-white",
    heroDText: "md:w-[212px] sm:w-[80px] w-[60px] md:h-[108px] sm:h-[48px] h-[38px] md:border-[18px] border-[9px] rounded-r-[50px] border-white sm:mx-2 mx-[6px]"
};
/* harmony default export */ const styles_0 = ((/* unused pure expression or super */ null && (styles_styles)));

;// CONCATENATED MODULE: ./components/StartSteps.jsx


const StartSteps = ({ number , text  })=>/*#__PURE__*/ _jsxs("div", {
        className: `${styles.flexCenter} flex-row`,
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: `${styles.flexCenter} w-[70px] h-[70px] rounded-[24px] bg-[#323f5d]`,
                children: /*#__PURE__*/ _jsxs("p", {
                    className: "font-bold text-[20px] text-white",
                    children: [
                        "0",
                        number
                    ]
                })
            }),
            /*#__PURE__*/ _jsx("p", {
                className: "flex-1 ml-[30px] font-normal text-[18px] text-[#B0B0B0] leading-[32px]",
                children: text
            })
        ]
    });
/* harmony default export */ const components_StartSteps = ((/* unused pure expression or super */ null && (StartSteps)));

;// CONCATENATED MODULE: ./components/NewFeatures.jsx


const NewFeatures = ({ imgUrl , title , subtitle  })=>/*#__PURE__*/ _jsxs("div", {
        className: "flex-1 flex flex-col sm:max-w-[250px] min-w-[210px]",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: `${styles.flexCenter} w-[70px] h-[70px] rounded-[24px] bg-[#323f5d]`,
                children: /*#__PURE__*/ _jsx("img", {
                    src: imgUrl,
                    alt: "icon",
                    className: "w-1/4 h-1/4 object-contain"
                })
            }),
            /*#__PURE__*/ _jsx("h1", {
                className: "mt-[26px] font-bold text-[24px] leading-[30px] text-white",
                children: title
            }),
            /*#__PURE__*/ _jsx("p", {
                className: "flex-1 mt-[16px] font-normal text-[18px] text-[#b0b0b0] leading-[32px]",
                children: subtitle
            })
        ]
    });
/* harmony default export */ const components_NewFeatures = ((/* unused pure expression or super */ null && (NewFeatures)));

// EXTERNAL MODULE: ./components/InsightCard.jsx
var InsightCard = __webpack_require__(1755);
// EXTERNAL MODULE: ./components/Footer.jsx
var Footer = __webpack_require__(7262);
var Footer_default = /*#__PURE__*/__webpack_require__.n(Footer);
;// CONCATENATED MODULE: ./components/index.js









;// CONCATENATED MODULE: ./components/WorldCard1.jsx

const WorldCard = ({ onClose  })=>{
    const handleCloseClick = ()=>{
        onClose();
    };
    return /*#__PURE__*/ _jsx("div", {
        className: "fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50",
        children: /*#__PURE__*/ _jsx("div", {
            className: "max-w-lg w-full mx-4 bg-white rounded-lg overflow-hidden shadow-lg",
            children: /*#__PURE__*/ _jsxs("div", {
                className: "p-6",
                children: [
                    /*#__PURE__*/ _jsx("h1", {
                        className: "text-3xl text-grey-800 font-bold text-center mb-4",
                        children: "Developer"
                    }),
                    /*#__PURE__*/ _jsx("h2", {
                        className: "text-xl text-grey-800 text-center mb-6",
                        children: "Autodidact | January 2020 - Today"
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        className: "text-gray-800 text-center mb-8",
                        children: "Experienced Autodidact Frontend Developer proficient in HTML5, CSS, JavaScript, ReactJS, SASS, Redux, TypeScript, and Next.js. Skilled in creating responsive designs, implementing state management, and building efficient user interfaces. Knowledge of jQuery, Bootstrap, and Styled Components. Passionate about self-learning and staying updated with industry trends."
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "flex flex-row justify-around",
                        children: /*#__PURE__*/ _jsx("button", {
                            onClick: handleCloseClick,
                            className: "inline-block px-6 py-2 text-white bg-blue-500 hover:bg-blue-600 rounded-full",
                            children: "Close"
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const WorldCard1 = ((/* unused pure expression or super */ null && (WorldCard)));

// EXTERNAL MODULE: ./sections/Hero.jsx
var Hero = __webpack_require__(7920);
var Hero_default = /*#__PURE__*/__webpack_require__.n(Hero);
// EXTERNAL MODULE: ./sections/About.jsx
var About = __webpack_require__(9048);
var About_default = /*#__PURE__*/__webpack_require__.n(About);
// EXTERNAL MODULE: ./sections/Explore.jsx
var Explore = __webpack_require__(632);
var Explore_default = /*#__PURE__*/__webpack_require__.n(Explore);
// EXTERNAL MODULE: ./sections/GetStarted.jsx
var GetStarted = __webpack_require__(2479);
var GetStarted_default = /*#__PURE__*/__webpack_require__.n(GetStarted);
// EXTERNAL MODULE: ./sections/WhatsNew.jsx
var WhatsNew = __webpack_require__(9266);
var WhatsNew_default = /*#__PURE__*/__webpack_require__.n(WhatsNew);
// EXTERNAL MODULE: ./sections/World.jsx
var World = __webpack_require__(443);
var World_default = /*#__PURE__*/__webpack_require__.n(World);
// EXTERNAL MODULE: ./sections/Insights.jsx
var Insights = __webpack_require__(3244);
var Insights_default = /*#__PURE__*/__webpack_require__.n(Insights);
// EXTERNAL MODULE: ./sections/Feedback.jsx
var Feedback = __webpack_require__(9099);
var Feedback_default = /*#__PURE__*/__webpack_require__.n(Feedback);
;// CONCATENATED MODULE: ./sections/index.js










;// CONCATENATED MODULE: ./app/page.js




const Page = ()=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "bg-primary-black overflow-hidden",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx((Navbar_default()), {}),
            /*#__PURE__*/ jsx_runtime.jsx((Hero_default()), {}),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx((About_default()), {}),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "gradient-03 z-0"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx((Explore_default()), {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx((GetStarted_default()), {}),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "gradient-04 z-0"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx((WhatsNew_default()), {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx((World_default()), {}),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx((Insights_default()), {}),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "gradient-04 z-0"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx((Feedback_default()), {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx((Footer_default()), {})
        ]
    });
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 5569:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\components\\CustomTexts.jsx");


/***/ }),

/***/ 2547:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\components\\ExploreCard.jsx");


/***/ }),

/***/ 7262:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\components\\Footer.jsx");


/***/ }),

/***/ 1755:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\components\\InsightCard.jsx");


/***/ }),

/***/ 3611:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\components\\Navbar.jsx");


/***/ }),

/***/ 9048:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\sections\\About.jsx");


/***/ }),

/***/ 632:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\sections\\Explore.jsx");


/***/ }),

/***/ 9099:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\sections\\Feedback.jsx");


/***/ }),

/***/ 2479:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\sections\\GetStarted.jsx");


/***/ }),

/***/ 7920:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\sections\\Hero.jsx");


/***/ }),

/***/ 3244:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\sections\\Insights.jsx");


/***/ }),

/***/ 9266:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\sections\\WhatsNew.jsx");


/***/ }),

/***/ 443:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("D:\\Programacion\\NextCVProyect\\sections\\World.jsx");


/***/ }),

/***/ 3002:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TitleText": () => (/* binding */ TitleText),
/* harmony export */   "TypingText": () => (/* binding */ TypingText)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(274);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3042);



const TypingText = ({ title , textStyles  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.p */ .E.p, {
        variants: _utils_motion__WEBPACK_IMPORTED_MODULE_1__/* .textContainer */ .AR,
        className: `font-normal text-[14px] text-secondary-white ${textStyles}`,
        children: Array.from(title).map((letter, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.span */ .E.span, {
                variants: _utils_motion__WEBPACK_IMPORTED_MODULE_1__/* .textVariant2 */ .lM,
                children: letter === " " ? "\xa0" : letter
            }, index))
    });
const TitleText = ({ title , textStyles  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.h2 */ .E.h2, {
        variants: _utils_motion__WEBPACK_IMPORTED_MODULE_1__/* .textVariant2 */ .lM,
        initial: "hidden",
        whileInView: "show",
        className: `mt-[8px] font-bold md:text-[64px] text-[40px] text-white ${textStyles}`,
        children: title
    });


/***/ }),

/***/ 3261:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(274);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5007);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3042);




const ExploreCard = ({ id , imgUrl , title , index , active , handleClick , section  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__/* .motion.div */ .E.div, {
        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .fadeIn */ .Ji)("right", "spring", index * 0.5, 0.75),
        className: `relative ${active === id ? "lg:flex-[3.5] flex-[10]" : "lg:flex-[0.5] flex-[2]"} flex items-center justify-center min-w-[170px] h-[700px] transition-[flex] duration-[0.7s] ease-out-flex cursor-pointer`,
        onClick: ()=>handleClick(id),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: imgUrl,
                alt: title,
                className: "absolute w-full h-full object-cover rounded-[24px]"
            }),
            active !== id ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: "font-semibold sm:text-[26px] text-[18px] text-white absolute z-0 lg:bottom-20 lg:rotate-[-90deg] lg:origin-[0,0]",
                children: title
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "absolute bottom-0 p-8 justify-start w-full flex-col lg:bg-[rgba(0,0,0,0.5)] sm:bg-[rgba(0,0,0,0.3)] rounded-b-[24px]",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: section,
                        className: "font-normal text-[16px] leading-[20px] text-white uppercase",
                        children: "Enter this world"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "mt-[24px] font-semibold sm:text-[32px] text-[24px] text-white",
                        children: title
                    })
                ]
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExploreCard);
1;


/***/ }),

/***/ 7959:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(274);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6333);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5007);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3042);





const Footer = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__/* .motion.footer */ .E.footer, {
        variants: _utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .footerVariants */ .FT,
        initial: "hidden",
        whileInView: "show",
        viewport: {
            once: true,
            amount: 0.25
        },
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].xPaddings */ .Z.xPaddings} py-8 relative`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "footer-gradient"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex flex-col gap-8`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-center justify-between flex-wrap gap-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                            className: "font-bold md:text-[64px] text-[44px] text-white",
                            children: "Hope you enjoy this journey."
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mb-[50px] h-[2px] bg-white opacity-10"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center justify-between flex-wrap gap-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "font-extrabold text-[24px] text-white",
                                        children: "Enzo Fiol"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "font-normal text-[14px] text-white opacity-50",
                                        children: "Copyright \xa9 2022 - 2023 Enzo Fiol. All rights reserved."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex gap-4",
                                        children: _constants__WEBPACK_IMPORTED_MODULE_1__/* .socials.map */ .UY.map((social)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                href: social.socialUrl,
                                                target: "_blank",
                                                rel: "noopener",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: social.url,
                                                    alt: social.name,
                                                    className: "w-[24px] h-[24px] object-contain cursor-pointer"
                                                }, social.name)
                                            }))
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 7774:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(274);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3042);



const InsightCard = ({ imgUrl , title , subtitle , index , url  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.div */ .E.div, {
        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_1__/* .fadeIn */ .Ji)("up", "spring", index * 0.5, 1),
        className: "flex md:flex-row flex-col gap-4",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: imgUrl,
                alt: "planet-01",
                className: "md:w-[270px] w-full h-[250px] rounded-[32px] object-cover"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-1 md:ml-[62px] flex flex-col max-w-[650px]",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                className: "font-normal lg:text-[42px] text-[26px] text-white",
                                children: title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mt-[16px] font-normal lg:text-[20px] text-[14px] text-secondary-white",
                                children: subtitle
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: url,
                        target: "_blank",
                        rel: "noopener",
                        className: "lg:flex hidden items-center justify-center w-[100px] h-[100px] rounded-full bg-transparent border-[1px] border-white",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/arrow.svg",
                            alt: "arrow",
                            className: "w-[40%] h-[40%] object-contain"
                        })
                    })
                ]
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InsightCard);


/***/ }),

/***/ 1505:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(274);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5007);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3042);




const Navbar = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__/* .motion.nav */ .E.nav, {
        variants: _utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .navVariants */ .yB,
        initial: "hidden",
        whileInView: "show",
        viewport: {
            once: true,
            amount: 0.25
        },
        className: `${_styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].xPaddings */ .Z.xPaddings} py-8 relative`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute w-[50%] inset-0 gradient-01"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${_styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex justify-center gap-8`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "font-extrabold text-[24px] leading-[30px] text-white",
                    children: "ENZOFIOL"
                })
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);


/***/ }),

/***/ 6150:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "NM": () => (/* reexport */ ExploreCard["default"]),
  "L4": () => (/* reexport */ InsightCard["default"]),
  "Oz": () => (/* reexport */ components_NewFeatures),
  "dy": () => (/* reexport */ components_StartSteps),
  "eN": () => (/* reexport */ CustomTexts.TitleText),
  "gw": () => (/* reexport */ CustomTexts.TypingText)
});

// UNUSED EXPORTS: Footer, Navbar

// EXTERNAL MODULE: ./components/Navbar.jsx
var Navbar = __webpack_require__(1505);
// EXTERNAL MODULE: ./components/CustomTexts.jsx
var CustomTexts = __webpack_require__(3002);
// EXTERNAL MODULE: ./components/ExploreCard.jsx
var ExploreCard = __webpack_require__(3261);
// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./styles/index.js
var styles = __webpack_require__(5007);
;// CONCATENATED MODULE: ./components/StartSteps.jsx


const StartSteps = ({ number , text  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${styles/* default.flexCenter */.Z.flexCenter} flex-row`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${styles/* default.flexCenter */.Z.flexCenter} w-[70px] h-[70px] rounded-[24px] bg-[#323f5d]`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "font-bold text-[20px] text-white",
                    children: [
                        "0",
                        number
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "flex-1 ml-[30px] font-normal text-[18px] text-[#B0B0B0] leading-[32px]",
                children: text
            })
        ]
    });
/* harmony default export */ const components_StartSteps = (StartSteps);

;// CONCATENATED MODULE: ./components/NewFeatures.jsx


const NewFeatures = ({ imgUrl , title , subtitle  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex-1 flex flex-col sm:max-w-[250px] min-w-[210px]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${styles/* default.flexCenter */.Z.flexCenter} w-[70px] h-[70px] rounded-[24px] bg-[#323f5d]`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: imgUrl,
                    alt: "icon",
                    className: "w-1/4 h-1/4 object-contain"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "mt-[26px] font-bold text-[24px] leading-[30px] text-white",
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "flex-1 mt-[16px] font-normal text-[18px] text-[#b0b0b0] leading-[32px]",
                children: subtitle
            })
        ]
    });
/* harmony default export */ const components_NewFeatures = (NewFeatures);

// EXTERNAL MODULE: ./components/InsightCard.jsx
var InsightCard = __webpack_require__(7774);
// EXTERNAL MODULE: ./components/Footer.jsx
var Footer = __webpack_require__(7959);
;// CONCATENATED MODULE: ./components/index.js










/***/ }),

/***/ 6333:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kn": () => (/* binding */ insights),
/* harmony export */   "UY": () => (/* binding */ socials),
/* harmony export */   "gw": () => (/* binding */ newFeatures),
/* harmony export */   "nw": () => (/* binding */ exploreWorlds),
/* harmony export */   "pT": () => (/* binding */ startingFeatures)
/* harmony export */ });
const exploreWorlds = [
    {
        id: "world-1",
        imgUrl: "/planet-02.png",
        title: "Realm of Adventures",
        section: "#about"
    },
    {
        id: "world-2",
        imgUrl: "/abbey.jpg",
        title: "Abbey of Knowledge",
        section: "#studies"
    },
    {
        id: "world-3",
        imgUrl: "/planet-03.png",
        title: "Warzone Citadel",
        section: "#experience"
    },
    {
        id: "world-4",
        imgUrl: "/armoury1.jpg",
        title: "Grand Armoury",
        section: "#resources"
    },
    {
        id: "world-5",
        imgUrl: "/darkportal.jpg",
        title: "Dark Portal",
        section: "#contact"
    }
];
const startingFeatures = [
    "Getting married with love of my life",
    "Exploring worlds gaming with my best friends",
    "Watching and reading about MCU, Game of Thrones, World History and Animes"
];
const newFeatures = [
    {
        imgUrl: "/vrpano.svg",
        title: "4-016 A. M. Arboit",
        subtitle: "Highschool | Electician Technician"
    },
    {
        imgUrl: "/vrpano.svg",
        title: "Lincoln American Institute",
        subtitle: "English Studies. Finished."
    },
    {
        imgUrl: "/vrpano.svg",
        title: "Freecode Camp",
        subtitle: "ReactJS, Redux, JQuery, Python, MySQL, MongoDB, Java, PHP."
    },
    {
        imgUrl: "/vrpano.svg",
        title: "Autodidact",
        subtitle: "JavaScript, HTML, CSS, SASS, Tailwind, Boostrap, Framer-Motion, NextJS, Python, GIT, TypeScript"
    }
];
const insights = [
    {
        imgUrl: "/astro.png",
        title: "Astro",
        subtitle: "Astro is the all-in-one web framework designed for speed. Pull your content from anywhere and deploy everywhere, all powered by your favorite UI components and libraries.",
        url: "https://astro.build/"
    },
    {
        imgUrl: "/nextjs13.png",
        title: "NextJS 13",
        subtitle: "Used by some of the world's largest companies, Next.js enables you to create full-stack Web applications by extending the latest React features, and integrating powerful Rust-based JavaScript tooling for the fastest builds.",
        url: "https://nextjs.org/"
    },
    {
        imgUrl: "/tailwinds.png",
        title: "Tailwind CSS",
        subtitle: "A utility-first CSS framework packed with classes like flex, pt-4, text-center and rotate-90 that can be composed to build any design, directly in your markup.",
        url: "https://tailwindcss.com/"
    }
];
const socials = [
    {
        name: "linkedin",
        url: "/linkedin.svg",
        socialUrl: "https://www.linkedin.com/in/enzofiol/"
    },
    {
        name: "instagram",
        url: "/instagram.svg",
        socialUrl: "https://www.instagram.com/enzos33/"
    }
];


/***/ }),

/***/ 1902:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(274);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6150);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5007);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3042);





const About = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].paddings */ .Z.paddings} realtive z-10`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "gradient-02 z-0"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__/* .motion.div */ .E.div, {
                variants: _utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .staggerContainer */ .Jm,
                initial: "hidden",
                whileInView: "show",
                viewport: {
                    once: true,
                    amount: 0.25
                },
                className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto ${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].flexCenter */ .Z.flexCenter} flex-col`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .TypingText */ .gw, {
                        title: " | About quest.",
                        textStyles: "text-center"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__/* .motion.p */ .E.p, {
                        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .fadeIn */ .Ji)("up", "tween", 0.2, 1),
                        className: "mt-[8px] font-normal sm:text-[32px] text-[20px] text-center text-secondary-white",
                        children: [
                            '" Verily, as a devoted',
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-extrabold text-white",
                                children: " Front-end Knight"
                            }),
                            ", my quest doth revolve around fashioning wondrous and",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "font-extrabold text-white",
                                children: [
                                    " ",
                                    "adaptive web interfaces",
                                    " "
                                ]
                            }),
                            "that doth captivate the eye and engage the senses. With meticulous care, I doth hone and refine the code to enhance its prowess, ensuring seamless",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "font-extrabold text-white",
                                children: [
                                    " ",
                                    "compatibility across all browsers",
                                    " "
                                ]
                            }),
                            'in the realm. Ever vigilant and receptive to the emergence of new technologies, I doth consistently deliver exceptional experiences unto the users, transporting them to realms beyond imagination. Pray, continue thy journey by scrolling henceforth, that thou mayest unravel more of this epic saga. "'
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__/* .motion.img */ .E.img, {
                        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .fadeIn */ .Ji)("up", "tween", 1.5, 1),
                        src: "/arrow-down.svg",
                        alt: "arrow down",
                        className: "w-[18px] h-[28px] object-contain mt-[28px]"
                    })
                ]
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (About);


/***/ }),

/***/ 8922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(274);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6150);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5007);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3042);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6333);







const Explore = ()=>{
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("world-2");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_3__/* ["default"].paddings */ .Z.paddings}`,
        id: "explore",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_6__/* .motion.div */ .E.div, {
            variants: _utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .staggerContainer */ .Jm,
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: true,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_3__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex flex-col`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .TypingText */ .gw, {
                    title: "| The Universe",
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .TitleText */ .eN, {
                    title: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            "Choose the world you want",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                className: "md:block hidden"
                            }),
                            "to explore"
                        ]
                    }),
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-[50px] flex lg:flex-row flex-col min-h-[70vh] gap-5",
                    children: _constants__WEBPACK_IMPORTED_MODULE_5__/* .exploreWorlds.map */ .nw.map((world, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .ExploreCard */ .NM, {
                            ...world,
                            index: index,
                            active: active,
                            handleClick: setActive
                        }, world.id))
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Explore);


/***/ }),

/***/ 8699:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(274);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5007);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3042);




const Feedback = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].paddings */ .Z.paddings}`,
        id: "contact",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__/* .motion.div */ .E.div, {
            variants: _utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .staggerContainer */ .Jm,
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: true,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex lg:flex-row flex-col gap-6`,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__/* .motion.div */ .E.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .fadeIn */ .Ji)("right", "tween", 0.2, 1),
                    className: "flex-[0.5] lg:max-w-[370px] flex justify-end flex-col gradient-05 sm:p-8 p-4 rounded-[32px] border-[1px] border-[#6A6A6A] relative",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "feedback-gradient"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mt-[8px] font-normal sm:text-[18px] text-[12px] sm:leading-[22.68px] leading-[16.68px] text-white",
                                children: "Enzo Fiol says:"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "mt-[24px] font-normal sm:text-[24px] text-[18px] sm:leading-[45.6px] leading-[39.6px] text-white",
                            children: "“As the final curtain falls on this vast universe, I, a weary yet triumphant developer, bid farewell. Together, we've traversed realms, conquering challenges and witnessing wonders. Our adventures shall be legendary, inspiring new heroes on untrodden paths. May destiny guide you to new horizons. Adieu, and may your spirit forever shine bright.”"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__/* .motion.div */ .E.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .fadeIn */ .Ji)("left", "tween", 0.2, 1),
                    className: "relative flex-1 flex justify-center items-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/planet-09.png",
                        alt: "planet-09",
                        className: "w-full lg:h-[610px] h-auto min-h-[210px] object-cover rounded-[40px]"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Feedback);


/***/ }),

/***/ 2046:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(274);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6150);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5007);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3042);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6333);






const GetStarted = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].padding */ .Z.padding} relative z-10 mt-24 pt-24 mb-72 ml-5`,
        id: "about",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__/* .motion.div */ .E.div, {
            variants: _utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .staggerContainer */ .Jm,
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: true,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex lg:flex-row flex-col gap-8`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__/* .motion.div */ .E.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .planetVariants */ .vk)("left"),
                    className: `flex-1 ${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].flexCenter */ .Z.flexCenter}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/get-started.png",
                        alt: "get-started",
                        className: "w-[90%] h-[90%] object-contain"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__/* .motion.div */ .E.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .fadeIn */ .Ji)("left", "tween", 0.2, 1),
                    className: "flex-[0.75] flex justify-center flex-col",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .TypingText */ .gw, {
                            title: "| About me"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .TitleText */ .eN, {
                            title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: "The best adventures I've had"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-[31px] flex flex-col max-w-[370px] gap-[24px]",
                            children: _constants__WEBPACK_IMPORTED_MODULE_4__/* .startingFeatures.map */ .pT.map((feature, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .StartSteps */ .dy, {
                                    number: index + 1,
                                    text: feature
                                }, feature))
                        })
                    ]
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GetStarted);


/***/ }),

/***/ 8857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(274);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5007);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3042);




const Hero = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].yPaddings */ .Z.yPaddings} sm:pl-16 pl-6 mb-24`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__/* .motion.div */ .E.div, {
            variants: _utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .staggerContainer */ .Jm,
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: true,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex flex-col`,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-center items-center flex-col z-10",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__/* .motion.h1 */ .E.h1, {
                            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .textVariant */ .wt)(1.2),
                            className: _styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].heroHeading */ .Z.heroHeading,
                            children: "Welcome to"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__/* .motion.div */ .E.div, {
                            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .textVariant */ .wt)(1.8),
                            className: "flex justify-center items-center z-99",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: _styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].heroHeading */ .Z.heroHeading,
                                children: "My World!"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__/* .motion.div */ .E.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .slideIn */ .Ym)("right", "tween", 0.2, 1),
                    className: "relative w-full md:-mt-[20px] -mt-[12px]",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute w-full h-[300px] hero-gradient rounded-tl-[140px] z-[0] -top-[30px]"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/cover.png",
                            alt: "cover",
                            className: "w-full sm:h-[500px] h-[350px] object-cover rounded-tl-[140px] z-10 relative"
                        })
                    ]
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);


/***/ }),

/***/ 5494:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(274);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5007);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6333);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3042);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6150);






const Insights = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].paddings */ .Z.paddings} relative z-10`,
        id: "resources",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__/* .motion.div */ .E.div, {
            variants: _utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .staggerContainer */ .Jm,
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: true,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex flex-col`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_4__/* .TypingText */ .gw, {
                    title: "| Most used resources",
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_4__/* .TitleText */ .eN, {
                    title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: "Recommended weapons and Utilites"
                    }),
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-[50px] flex flex-col gap-[30px]",
                    children: _constants__WEBPACK_IMPORTED_MODULE_2__/* .insights.map */ .Kn.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_4__/* .InsightCard */ .L4, {
                            ...item,
                            index: index + 1
                        }, `insight-${index}`))
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Insights);


/***/ }),

/***/ 7903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(274);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6150);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5007);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3042);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6333);






const WhatsNew = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].padding */ .Z.padding} relative z-10 pt-14 mb-48 ml-5`,
        id: "studies",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__/* .motion.div */ .E.div, {
            variants: _utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .staggerContainer */ .Jm,
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: true,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex lg:flex-row flex-col gap-8`,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__/* .motion.div */ .E.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .fadeIn */ .Ji)("left", "tween", 0.2, 1),
                    className: "flex-[0.75] flex justify-center flex-col",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .TypingText */ .gw, {
                            title: "| Studies"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .TitleText */ .eN, {
                            title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: "Where do I acquire my knowledge?"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-[48px] flex flex-wrap justify-between gap-[24px]",
                            children: _constants__WEBPACK_IMPORTED_MODULE_4__/* .newFeatures.map */ .gw.map((feature)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .NewFeatures */ .Oz, {
                                    ...feature
                                }, feature.title))
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__/* .motion.div */ .E.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .planetVariants */ .vk)("right"),
                    className: `flex-1 ${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].flexCenter */ .Z.flexCenter}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/whats-new.png",
                        alt: "whats-new",
                        className: "w-[90%] h-[90%] object-contain"
                    })
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WhatsNew);


/***/ }),

/***/ 458:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ sections_World)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 183 modules
var motion = __webpack_require__(274);
// EXTERNAL MODULE: ./components/index.js + 2 modules
var components = __webpack_require__(6150);
// EXTERNAL MODULE: ./styles/index.js
var styles = __webpack_require__(5007);
// EXTERNAL MODULE: ./utils/motion.js
var utils_motion = __webpack_require__(3042);
;// CONCATENATED MODULE: ./components/WorldCard1.jsx

const WorldCard = ({ onClose  })=>{
    const handleCloseClick = ()=>{
        onClose();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "max-w-lg w-full mx-4 bg-white rounded-lg overflow-hidden shadow-lg",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl text-grey-800 font-bold text-center mb-4",
                        children: "Developer"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-xl text-grey-800 text-center mb-6",
                        children: "Autodidact | January 2020 - Today"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-gray-800 text-center mb-8",
                        children: "Experienced Autodidact Frontend Developer proficient in HTML5, CSS, JavaScript, ReactJS, SASS, Redux, TypeScript, and Next.js. Skilled in creating responsive designs, implementing state management, and building efficient user interfaces. Knowledge of jQuery, Bootstrap, and Styled Components. Passionate about self-learning and staying updated with industry trends."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex flex-row justify-around",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: handleCloseClick,
                            className: "inline-block px-6 py-2 text-white bg-blue-500 hover:bg-blue-600 rounded-full",
                            children: "Close"
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const WorldCard1 = (WorldCard);

;// CONCATENATED MODULE: ./components/WorldCard2.jsx

const WorldCard2 = ({ onClose  })=>{
    const handleCloseClick = ()=>{
        onClose();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "max-w-lg w-full mx-4 bg-white rounded-lg overflow-hidden shadow-lg",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl text-grey-800 font-bold text-center mb-4",
                        children: "Frontend Developer"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-xl text-grey-800 text-center mb-6",
                        children: "Victoria's MakeUp | February 2021 - April 2021"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-gray-800 text-center mb-8",
                        children: "I built a makeup website using React JS, SASS, and Node.js, creating a seamless and engaging user experience. Leveraging React's responsive framework, the website delivers fast load times and smooth transitions. The visually appealing design is enhanced with SASS, streamlining CSS development. With Node.js powering the backend, the website handles high traffic volumes and complex data processing. This makeup website showcases the capabilities of modern web development technology, providing a top destination for makeup enthusiasts worldwide."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row justify-around",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://beauty-planner-2db0e.web.app/",
                                rel: "noopener",
                                target: "_blank",
                                className: "inline-block bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full",
                                children: "Link to proyect"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: handleCloseClick,
                                className: "inline-block px-6 py-2 text-white bg-blue-500 hover:bg-blue-600 rounded-full",
                                children: "Close"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const components_WorldCard2 = (WorldCard2);

;// CONCATENATED MODULE: ./components/WorldCard3.jsx

const WorldCard3 = ({ onClose  })=>{
    const handleCloseClick = ()=>{
        onClose();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "max-w-lg w-full mx-4 bg-white rounded-lg overflow-hidden shadow-lg",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl text-grey-800 font-bold text-center mb-4",
                        children: "'SEO Developer - Fullstack Developer'"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-xl text-grey-800 text-center mb-6",
                        children: "'SOUP Agency LTDA | January 2022 - June 2023'"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-gray-800 text-center mb-8",
                        children: "'The Haircare E-Commerce project is an online platform that offers a wide range of hair care products. Developed with modern technologies like React, Node.js, and MongoDB, it prioritizes user-friendliness and efficiency. Key features include personalized customer profiles, purchase history, and a powerful search engine. The platform supports multiple payment methods and focuses on scalability and security. Measures such as data encryption and two-factor authentication are implemented to protect customer data.'"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row justify-around",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://pumphaircare.com/",
                                rel: "noopener",
                                target: "_blank",
                                className: "inline-block bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full",
                                children: "Link to proyect"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: handleCloseClick,
                                className: "inline-block px-6 py-2 text-white bg-blue-500 hover:bg-blue-600 rounded-full",
                                children: "Close"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const components_WorldCard3 = (WorldCard3);

;// CONCATENATED MODULE: ./sections/World.jsx










const World = ()=>{
    const [isCardVisible, setIsCardVisible] = (0,react_.useState)(false);
    const cardRef = (0,react_.useRef)(null);
    const handleSectionClick = (id)=>{
        document.startViewTransition(()=>setIsCardVisible(id));
    };
    const handleCardClose = ()=>{
        document.startViewTransition(()=>setIsCardVisible(false));
    };
    (0,react_.useEffect)(()=>{
        const handleClickOutside = (event)=>{
            if (cardRef.current && !cardRef.current.contains(event.target)) {
                setIsCardVisible(true);
            }
            console.log("useEffect");
        };
        document.addEventListener("click", handleClickOutside);
        return ()=>{
            document.removeEventListener("click", handleClickOutside);
        };
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: `${styles/* default.padding */.Z.padding} relative z-10 pt-14 mb-24`,
        id: "experience",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
            variants: utils_motion/* staggerContainer */.Jm,
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: true,
                amount: 0.25
            },
            className: `${styles/* default.innerWidth */.Z.innerWidth} mx-auto flex flex-col`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(components/* TypingText */.gw, {
                    title: "| Experience",
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(components/* TitleText */.eN, {
                    title: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                        children: "The best fights and works I've been in"
                    }),
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                    variants: (0,utils_motion/* fadeIn */.Ji)("up", "tween", 0.3, 1),
                    className: "relative mt-[68px] flex w-full h-[550px]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/map.png",
                            alt: "map",
                            className: "w-full h-full object-cover"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "absolute bottom-20 right-20 w-[70px] h-[70px] p-[6px] rounded-full bg-[#5d6680]",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "people-01.png",
                                alt: "people",
                                className: "w-full h-full"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "absolute bottom-20 left-52 w-[70px] h-[70px] p-[6px] rounded-full bg-[#5d6680]",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "people-02.png",
                                alt: "people",
                                className: "w-full h-full"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "absolute bottom-20 left-32 w-[70px] h-[70px] p-[6px] rounded-full bg-[#5d6680]",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "people-03.png",
                                alt: "people",
                                className: "w-full h-full"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/workBlur3.png",
                            className: "absolute right-[17px] bottom-[10vh] h-[200px] w-[250px]"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/workBlur3.png",
                            className: "absolute left-[6vw] bottom-[10vh] h-[200px] w-[280px]"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/workBlur3.png",
                            className: "absolute left-[0vw] bottom-[10vh] h-[200px] w-[200px] hover:scale-100"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            onClick: ()=>handleSectionClick(1),
                            className: "absolute bottom-40 left-20 w-[120px] h-[90px] p-[6px] ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/workBg3.png",
                                    className: "rounded-lg cursor-pointer"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-white absolute bottom-1 right-2 text-xs text-center",
                                    children: "More..."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "absolute bottom-6 text-white font-semibold text-sm right-[40px]",
                                    children: "Home"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            onClick: ()=>handleSectionClick(2),
                            className: "absolute bottom-40 left-52 w-[120px] h-[90px] p-[6px]",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/workBg2.png",
                                    className: "rounded-lg cursor-pointer "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-white absolute bottom-0 right-2 text-xs text-center",
                                    children: "More..."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "absolute bottom-4 right-2 text-white font-semibold text-sm",
                                    children: "Beauty Planner"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            onClick: ()=>handleSectionClick(3),
                            className: "absolute bottom-40 right-20 w-[120px] h-[90px] p-[6px]",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/workBg3.png",
                                    className: "rounded-lg cursor-pointer"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-white absolute bottom-1 right-2 text-xs text-center",
                                    children: "More..."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "absolute bottom-6 text-white text-sm font-semibold right-[10px]",
                                    children: "Pump Haircare"
                                })
                            ]
                        }),
                        isCardVisible == 1 && /*#__PURE__*/ jsx_runtime_.jsx(WorldCard1, {
                            onClose: handleCardClose
                        }),
                        isCardVisible == 2 && /*#__PURE__*/ jsx_runtime_.jsx(components_WorldCard2, {
                            onClose: handleCardClose
                        }),
                        isCardVisible == 3 && /*#__PURE__*/ jsx_runtime_.jsx(components_WorldCard3, {
                            onClose: handleCardClose
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const sections_World = (World);


/***/ }),

/***/ 5007:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const styles = {
    innerWidth: "2xl:max-w-[1280px] w-full",
    interWidth: "lg:w-[80%] w-[100%]",
    paddings: "sm:p-16 xs:p-8 px-6 py-12",
    yPaddings: "sm:py-16 xs:py-8 py-12",
    xPaddings: "sm:px-16 px-6",
    topPaddings: "sm:pt-16 xs:pt-8 pt-12",
    bottomPaddings: "sm:pb-16 xs:pb-8 pb-12",
    flexCenter: "flex justify-center items-center",
    flexStart: "flex justify-start items-start",
    flexEnd: "flex justify-end",
    navPadding: "pt-[98px]",
    // hero section
    heroHeading: "font-bold lg:text-[144px] md:text-[100px] sm:text-[60px] text-[44px] lg:leading-[158.4px] md:leading-[114.4px] sm:leading-[74.4px] leading-[64.4px] uppercase text-white",
    heroDText: "md:w-[212px] sm:w-[80px] w-[60px] md:h-[108px] sm:h-[48px] h-[38px] md:border-[18px] border-[9px] rounded-r-[50px] border-white sm:mx-2 mx-[6px]"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (styles);


/***/ }),

/***/ 3042:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AR": () => (/* binding */ textContainer),
/* harmony export */   "FT": () => (/* binding */ footerVariants),
/* harmony export */   "Ji": () => (/* binding */ fadeIn),
/* harmony export */   "Jm": () => (/* binding */ staggerContainer),
/* harmony export */   "Ym": () => (/* binding */ slideIn),
/* harmony export */   "lM": () => (/* binding */ textVariant2),
/* harmony export */   "vk": () => (/* binding */ planetVariants),
/* harmony export */   "wt": () => (/* binding */ textVariant),
/* harmony export */   "yB": () => (/* binding */ navVariants)
/* harmony export */ });
/* unused harmony export zoomIn */
const navVariants = {
    hidden: {
        opacity: 0,
        y: -50,
        transition: {
            type: "spring",
            stiffness: 300,
            damping: 140
        }
    },
    show: {
        opacity: 1,
        y: 0,
        transition: {
            type: "spring",
            stiffness: 80,
            delay: 0.2
        }
    }
};
const slideIn = (direction, type, delay, duration)=>({
        hidden: {
            x: direction === "left" ? "-100%" : direction === "right" ? "100vw" : 0,
            y: direction === "up" ? "100%" : direction === "down" ? "100%" : 0
        },
        show: {
            x: 0,
            y: 0,
            transition: {
                type,
                delay,
                duration,
                ease: "easeOut"
            }
        }
    });
const staggerContainer = (staggerChildren, delayChildren)=>({
        hidden: {},
        show: {
            transition: {
                staggerChildren,
                delayChildren
            }
        }
    });
const textVariant = (delay)=>({
        hidden: {
            y: 50,
            opacity: 0
        },
        show: {
            y: 0,
            opacity: 1,
            transition: {
                type: "spring",
                duration: 1.25,
                delay
            }
        }
    });
const textContainer = {
    hidden: {
        opacity: 0
    },
    show: (i = 1)=>({
            opacity: 1,
            transition: {
                staggerChildren: 0.1,
                delayChildren: i * 0.1
            }
        })
};
const textVariant2 = {
    hidden: {
        opacity: 0,
        y: 20
    },
    show: {
        opacity: 1,
        y: 0,
        transition: {
            type: "tween",
            ease: "easeIn"
        }
    }
};
const fadeIn = (direction, type, delay, duration)=>({
        hidden: {
            x: direction === "left" ? "100vw" : direction === "right" ? -100 : 0,
            y: direction === "up" ? 100 : direction === "down" ? -100 : 0,
            opacity: 0
        },
        show: {
            x: 0,
            y: 0,
            opacity: 1,
            transition: {
                type,
                delay,
                duration,
                ease: "easeOut"
            }
        }
    });
const planetVariants = (direction)=>({
        hidden: {
            x: direction === "left" ? "-100vw" : "100vw",
            rotate: 150
        },
        show: {
            x: 0,
            rotate: 0,
            transition: {
                type: "spring",
                duration: 1.8,
                delay: 0.5
            }
        }
    });
const zoomIn = (delay, duration)=>({
        hidden: {
            scale: 0,
            opacity: 0
        },
        show: {
            scale: 1,
            opacity: 1,
            transition: {
                type: "tween",
                delay,
                duration,
                ease: "easeOut"
            }
        }
    });
const footerVariants = {
    hidden: {
        opacity: 0,
        y: 50,
        transition: {
            type: "spring",
            stiffness: 300,
            damping: 140
        }
    },
    show: {
        opacity: 1,
        y: 0,
        transition: {
            type: "spring",
            stiffness: 80,
            delay: 0.5
        }
    }
};


/***/ }),

/***/ 6495:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [754], () => (__webpack_exec__(2090)));
module.exports = __webpack_exports__;

})();